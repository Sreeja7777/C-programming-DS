//Max of 3 nos using Logical operator

#include <stdio.h>

int main()
{
    int a, b, c;

    // Asking for input
    printf("Enter three numbers: ");
    scanf("%d %d %d", &a, &b, &c);

    // Check max using logical operators
    if (a >= b && a >= c)
    {
        printf("%d is the largest.\n", a);
    }
    else if (b >= a && b >= c)
    {
        printf("%d is the largest.\n", b);
    }
    else
    {
        printf("%d is the largest.\n", c);
    }

    return 0;
}
